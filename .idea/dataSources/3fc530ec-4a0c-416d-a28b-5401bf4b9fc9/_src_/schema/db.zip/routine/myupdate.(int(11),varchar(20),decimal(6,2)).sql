CREATE PROCEDURE `myupdate`(`did` INT(11), `n` VARCHAR(20), `p` DECIMAL(6, 2))
  BEGIN
    update db_bookinfo set bname=n,bprice=p where bid=did;
  END