CREATE PROCEDURE `myshow`()
  begin
    select * from db_bookinfo;
end