CREATE PROCEDURE `upd`(`sid` INT(11), `a` VARCHAR(20))
  BEGIN 
    update student set address=a where id = sid;
  END