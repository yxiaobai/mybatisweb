CREATE PROCEDURE `cc`()
  begin
    select count(*) from db_bookinfo into myc;
  end