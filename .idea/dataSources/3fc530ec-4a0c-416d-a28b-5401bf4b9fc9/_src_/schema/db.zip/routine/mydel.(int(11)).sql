CREATE PROCEDURE `mydel`(`did` INT(11))
  BEGIN
  delete from db_bookinfo where bid=did;
  END