CREATE PROCEDURE `mysave`(`n` VARCHAR(20), `p` DECIMAL(6, 2))
  BEGIN
    insert into db_bookinfo values(null,n,p);
  END